package Controlador;

import Modelo.MascotaDAO;
import Modelo.ProductosDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@MultipartConfig
@WebServlet(name = "ControladorImg", urlPatterns = {"/ControladorImg"})
public class ControladorImg extends HttpServlet {

    ProductosDAO pdao = new ProductosDAO();
    MascotaDAO mao = new MascotaDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        pdao.listarImg(id, response);
//        processRequest(request, response);

        int idm = Integer.parseInt(request.getParameter("id"));
        mao.listarImg(id, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
